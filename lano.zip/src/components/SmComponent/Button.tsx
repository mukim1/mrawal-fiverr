const Button = () => {
  return (
    <button className=" px-10 py-5 bg-[rgb(12,30,223)] rounded-md text-white text-lg ">
      Books demo
    </button>
  );
};

export default Button;
